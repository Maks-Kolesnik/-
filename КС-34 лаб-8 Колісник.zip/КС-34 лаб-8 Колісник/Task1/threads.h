#define THREADS_H_

void *producer(void *arg);
void *consumer(void *arg);

