#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

static void userHaldler(int signo) {
	if (signo == SIGUSR1) {
		printf("Catched signal SIGUSR1\n");
		exit(0);
	} else if (signo == SIGINT) {
		printf("Catched SIGINT signal\n");
	} else if (signo == SIGTERM){
		printf("Catched SIGTERM signal\n");
	} 
}

int main(void) {
	printf("PID: %d\n", (int)getpid());
	
	if (signal(SIGUSR1, userHaldler) == SIG_ERR) {
		printf("Error while setting user handler for SIGURS1");
		exit(1);
	}
	
	if (signal(SIGINT, userHaldler) == SIG_ERR) {
		printf("Error while setting user handler for SIGINT");
		exit(1);
	}
	
	if (signal(SIGTERM, userHaldler) == SIG_ERR) {
		printf("Error while setting user handler for SIGTERM");
		exit(1);
	}
	
	if (signal(SIGPROF, SIG_DFL) == SIG_ERR) {
		printf("Error while setting default handler for SIGPROF\n");
		exit(1);
	}
	
	if (signal(SIGHUP, SIG_IGN) == SIG_ERR) {
		printf("Error while setting ignor for SUGHUP\n");
		exit(1);
	}

	
	while(1) {
		printf("The process is waiting for signal\n");
		pause();
		
	}
	
	return 0;
}
