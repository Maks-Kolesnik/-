#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <wait.h>

void userHandler(int signo, siginfo_t* sign, void* ucontext) {
  extern const char* const sys_siglist[];
  printf("\nNumber of the signal: %d\tName of signal: \"%s\"\tSignal Information: %d\n", sign->si_signo, sys_siglist[signo], sign->si_value.sival_int);
}

int main(int argc, char** args) {
  int repsNum;
  pid_t pid;

  if (argc == 2) {
    repsNum = atoi(args[1]);
  }
  else {
    repsNum = 10;
    printf("You forgot to enter amount of processes");
  }
  
  pid = fork();
  
  if(pid == -1) {
    printf("Creating error!\n");
    exit(1);
  } else if(pid == 0) {
    struct sigaction act;
    sigfillset(&act.sa_mask);
    act.sa_flags = SA_SIGINFO;
    act.sa_sigaction = userHandler;
    sigaction(SIGUSR1, &act, NULL);
    while(1) {
      pause();
    }
  } else {
    for(int i = 1; i <= repsNum; i++) {
      sleep(1);
      sigval_t value;
      value.sival_int = i;
      if (sigqueue (pid, SIGUSR1, value) != 0) {
        printf("Error while sending signal!\n");
        exit(1);
      }
    }
    sleep(3);
    kill(pid, SIGTERM);
    wait(NULL);
  }
  
  return 0;
}
