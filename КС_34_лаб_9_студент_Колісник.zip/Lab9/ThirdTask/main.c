#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

#define WAIT 1

sig_atomic_t ntimes = 0;

pid_t alarm_pid;

int main(void) {
	pid_t pid, ppid;
	int count = 0;
	void parent_action(int), child_action(int), alarm_action(int);
	
	if (signal(SIGALRM, alarm_action) == SIG_ERR) {
		printf("Cannot handle SIGALRM!\n");
		exit(1);
	}
	
	switch(pid = fork()) {
	case -1:
		exit(1);
	
	case 0:
		if (signal(SIGUSR1, child_action) == SIG_ERR) {
			printf("Cannot handle SIGUSR1!\n");
			exit(1);
		}
		
		ppid = getppid();
		alarm_pid = ppid;
		
		
		while(count != 10) {
			kill(ppid, SIGUSR1);
			alarm(WAIT);
			pause();
			alarm(0);
			count++;
		}
		
	default:
		if (signal(SIGUSR1, parent_action) == SIG_ERR) {
			printf("Cannot handle SIGUSR1!\n");
			exit(EXIT_FAILURE);
		}
		alarm_pid = pid;
		while(count!=10) {
			alarm(WAIT);
			pause();
			alarm(0);
			count++;
			kill(pid, SIGUSR1);
		}
	}
	return 0;
}


void alarm_action(int sig) {
	kill(alarm_pid, SIGUSR1);
}

void parent_action(int sig) {
	extern const char * const sys_siglist[];
	printf("Parent process (%d) get %s (num)%d\n", (int)getpid(), sys_siglist[sig], 
		++ntimes);
}

void child_action(int sig) {
	printf("Child process (%d) get %s (num)%d\n", (int)getpid(), sys_siglist[sig],
		++ntimes);
}
