#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>


#define BELLS "\007\007\007" 

sig_atomic_t alarm_flag = 0;


void setflag(int sig) {
	alarm_flag = 1;
}

int main(int argc, char **argv) {
	int nsecs, j;
	pid_t pid;
	static struct sigaction act;
	
	if (argc <= 2) {
		printf("Wrong strating command in command line.");
		exit(1);
	}

	if ( (nsecs = atoi(argv[1])) <= 0) {
		printf("Incorrect time\n");
		exit(1);
	}
	
	switch(pid = fork()) {
	case -1:
		exit(1);
	case 0:
		break;
	default: 
		printf("Child process with id %d is working\n", pid);
		printf("Wait a signal after %d second\n", nsecs);
		exit(0);
	}
	
	act.sa_handler = setflag;
	sigaction(SIGALRM, &act, NULL);
	alarm(nsecs);
	pause();
	
	if (alarm_flag == 1) {
		printf(BELLS);
		for (j = 2; j < argc; j++)
			printf("%s ", argv[j]);
		printf("\n");
	}
	
	return 0;
}
